package com.shahdsalah.simpledictionary;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class AddEditActivity extends AppCompatActivity {

    private EditText etWord, etMeaning;
    private Button btnSave;

    private boolean isEdit = false;
    private int position = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_edit);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etWord = findViewById(R.id.etWord);
        etMeaning = findViewById(R.id.etMeaning);
        btnSave = findViewById(R.id.btnSave);

        Intent intent = getIntent();

        if (intent.hasExtra("edit")) {
            isEdit = intent.getBooleanExtra("edit", false);
        }

        if (isEdit) {
            position = intent.getIntExtra("position", -1);
            etWord.setText(intent.getStringExtra("word"));
            etMeaning.setText(intent.getStringExtra("meaning"));
        }

        btnSave.setOnClickListener(v -> {
            Intent resultIntent = new Intent();

            resultIntent.putExtra("word", etWord.getText().toString());
            resultIntent.putExtra("meaning", etMeaning.getText().toString());
            resultIntent.putExtra("position", position);
            resultIntent.putExtra("edit", isEdit);

            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}